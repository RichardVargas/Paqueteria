﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Motocicletas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btningresa_Click(object sender, EventArgs e)
        {

            if (txtusuario.Text == "Motocicles" && txtcontrase.Text == "12345")
            {
                MessageBox.Show("Usuario en proceso");
                Principal Form1 = new Principal();
                Form1.Show();
            }
            else
            {
                MessageBox.Show("Usuario Incorrecto");
            }
        }
    }
}
