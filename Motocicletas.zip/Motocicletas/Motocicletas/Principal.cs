﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Motocicletas
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void agregarMotosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AgregarPro Principal = new AgregarPro();
            Principal.Show();
        }

        private void verInventarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Productos Principal = new Productos();
            Principal.Show();
        }

        private void marcasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cliente Principal = new Cliente();
            Principal.Show();
        }

        private void ventasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _ Principal = new _();
            Principal.Show();
        }

        private void ventasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Ventas Principal = new Ventas();
            Principal.Show();
        }
    }
}
