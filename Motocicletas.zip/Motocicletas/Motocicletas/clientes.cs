﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Motocicletas
{
    class clientes
    {
        public string action { get; set; }
        
        public clientes()
        {
            action = "Clientes";
        }
    };
    class Resultsclie
    {
        public int idClientes { get; set; }
        public string nombre { get; set; }
        public string Apellidos { get; set; }
        public string Ciudad { get; set; }
    };
}
