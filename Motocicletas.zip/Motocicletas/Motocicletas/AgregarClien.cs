﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;

namespace Motocicletas
{
    public partial class _ : Form
    {
        private Button btnagrega;
        private Label label1;
        private TextBox txtciudad;
        private TextBox txtApellidos;
        private TextBox txtnombreC;
        private Label label5;
        private Label label3;
        private Label label2;
        private DataGridView dataGridView1;
        private Button btnregresarPro;
        private Panel panel1;

        public _()
        {
            InitializeComponent();
            mostrar();
        }

        private void InitializeComponent()
        {
            this.btnagrega = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtciudad = new System.Windows.Forms.TextBox();
            this.txtApellidos = new System.Windows.Forms.TextBox();
            this.txtnombreC = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnregresarPro = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnagrega
            // 
            this.btnagrega.Location = new System.Drawing.Point(180, 198);
            this.btnagrega.Name = "btnagrega";
            this.btnagrega.Size = new System.Drawing.Size(75, 23);
            this.btnagrega.TabIndex = 0;
            this.btnagrega.Text = "Agregar";
            this.btnagrega.UseVisualStyleBackColor = true;
            this.btnagrega.Click += new System.EventHandler(this.btnagrega_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this.btnagrega);
            this.panel1.Controls.Add(this.txtciudad);
            this.panel1.Controls.Add(this.txtApellidos);
            this.panel1.Controls.Add(this.txtnombreC);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(273, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(391, 235);
            this.panel1.TabIndex = 1;
            // 
            // txtciudad
            // 
            this.txtciudad.Location = new System.Drawing.Point(161, 126);
            this.txtciudad.Name = "txtciudad";
            this.txtciudad.Size = new System.Drawing.Size(120, 20);
            this.txtciudad.TabIndex = 11;
            // 
            // txtApellidos
            // 
            this.txtApellidos.Location = new System.Drawing.Point(161, 87);
            this.txtApellidos.Name = "txtApellidos";
            this.txtApellidos.Size = new System.Drawing.Size(120, 20);
            this.txtApellidos.TabIndex = 9;
            // 
            // txtnombreC
            // 
            this.txtnombreC.Location = new System.Drawing.Point(161, 55);
            this.txtnombreC.Name = "txtnombreC";
            this.txtnombreC.Size = new System.Drawing.Size(120, 20);
            this.txtnombreC.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(36, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Ciudad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Apellidos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(87, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Agregar nuevo cliente";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 245);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(931, 170);
            this.dataGridView1.TabIndex = 2;
            // 
            // btnregresarPro
            // 
            this.btnregresarPro.BackColor = System.Drawing.Color.IndianRed;
            this.btnregresarPro.Location = new System.Drawing.Point(755, 9);
            this.btnregresarPro.Name = "btnregresarPro";
            this.btnregresarPro.Size = new System.Drawing.Size(173, 29);
            this.btnregresarPro.TabIndex = 3;
            this.btnregresarPro.Text = "Regresar";
            this.btnregresarPro.UseVisualStyleBackColor = false;
            this.btnregresarPro.Click += new System.EventHandler(this.btnregresarPro_Click);
            // 
            // _
            // 
            this.ClientSize = new System.Drawing.Size(940, 427);
            this.Controls.Add(this.btnregresarPro);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Name = "_";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        private void btnregresarPro_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnagrega_Click(object sender, EventArgs e)
        {
            Servicio miServicio = new Servicio();
            AgregarCli cliente = new AgregarCli();

            cliente.Nombre = txtnombreC.Text;
            cliente.Apellidos = txtApellidos.Text;
            cliente.Ciudad = txtciudad.Text;
       
            JavaScriptSerializer ser = new JavaScriptSerializer();
            string body = ser.Serialize(cliente);

            //MessageBox.Show(body);
            string resultados = miServicio.llamarServicio(body);
            mostrar();
        }
        public void mostrar()
        {
            Servicio miServicio = new Servicio();
            clientes parametros = new clientes();
            JavaScriptSerializer ser = new JavaScriptSerializer();
            string body = ser.Serialize(parametros);
            //MessageBox.Show(body);
            string resultados = miServicio.llamarServicio(body);
            var productos = ser.Deserialize<List<Resultsclie>>(resultados);
            // MessageBox.Show(resultados);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = productos;
        }
    }
}
