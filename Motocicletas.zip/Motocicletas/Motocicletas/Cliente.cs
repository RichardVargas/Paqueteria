﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;

namespace Motocicletas
{
    public partial class Cliente : Form
    {
        public Cliente()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnclientes_Click(object sender, EventArgs e)
        {
            Servicio miServicio = new Servicio();
            clientes parametros = new clientes();
            JavaScriptSerializer ser = new JavaScriptSerializer();
            string body = ser.Serialize(parametros);
            //MessageBox.Show(body);
            string resultados = miServicio.llamarServicio(body);
            var clientes = ser.Deserialize<List<Resultsclie>>(resultados);
            // MessageBox.Show(resultados);
            dtgcliente.DataSource = null;
            dtgcliente.DataSource = clientes;
        }

        private void btnbusclient_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dtgcliente.Rows)
            {
                // int Nombre = int.Parse(row.Cells[0].Value.ToString());
                string nombre= row.Cells[1].Value.ToString();
                if (row.Cells[1].Value.ToString().TrimEnd().TrimStart() == txtnameclient.Text)
                {
                    row.Selected = true;
                }
              
            }
        }
    }
}
