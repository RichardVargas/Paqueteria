﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Motocicletas
{
    class Ventass
    {
        public int idMoto { get; set; }
        public int idCliente { get; set; }
        public int Costo { get; set; }

        public string action { get; set; }


        public Ventass()
        {
            action = "Venta";
        }
    }
        class resultado
        {
        public int idMoto { get; set; }
        public int idCliente { get; set; }
        public int Costo { get; set; }
    }
}
