﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;

namespace Motocicletas
{
    public partial class AgregarPro : Form
    {
        public AgregarPro()
        {
            InitializeComponent();
            mostrar();
            
        }

        private void btnregre_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Servicio miServicio = new Servicio();
            AgregarProo parametros = new AgregarProo();

            parametros.Nombre = txtname.Text;
            parametros.Marca = txtmarca.Text;
            parametros.Costo = txtcosto.Text;
            parametros.Existencia = txtexistencia.Text;

            JavaScriptSerializer ser = new JavaScriptSerializer();
            string body = ser.Serialize(parametros);

            //MessageBox.Show(body);
            string result = miServicio.llamarServicio(body);

            //var productos = ser.Deserialize<List<result>>(result);
            //MessageBox.Show(resultados);
            dgvagregar.DataSource = null;
            dgvagregar.DataSource = result;
            mostrar();
        }
        public void mostrarPro()
        {

        }
        public void mostrar()
        {
            Servicio miServicio = new Servicio();
            producto parametros = new producto();
            JavaScriptSerializer ser = new JavaScriptSerializer();
            string body = ser.Serialize(parametros);
            //MessageBox.Show(body);
            string resultados = miServicio.llamarServicio(body);
            var productos = ser.Deserialize<List<resultprodu>>(resultados);
            // MessageBox.Show(resultados);
            dgvagregar.DataSource = null;
            dgvagregar.DataSource = productos;
        }
    }
}
