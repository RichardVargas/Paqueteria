﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Motocicletas
{
    class AgregarProo
    {
        public string action { get; set; }
        public string Nombre { get; set; }
        public string Marca{ get; set; }
        public string Costo{ get; set; }
        public string Existencia { get; set; }

        public AgregarProo()
        {
            action = "AgregarM";
        }
    }
    class result
    {
        public string Nombre { get; set; }
        public string Marca { get; set; }
        public string Costo { get; set; }
        public string Existencia { get; set; }
    }

}