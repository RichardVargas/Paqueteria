﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace Motocicletas
{
    public partial class Ventas : Form
    {
        public Ventas()
        {
            InitializeComponent();
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnregresarPro_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            Servicio miServicio = new Servicio();
           Ventass parametros = new Ventass();
            JavaScriptSerializer ser = new JavaScriptSerializer();
            string body = ser.Serialize(parametros);
            //MessageBox.Show(body);
            string resultados = miServicio.llamarServicio(body);
            var productos = ser.Deserialize<List<resultado>>(resultados);
            // MessageBox.Show(resultados);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = productos;

        }
    }
}
