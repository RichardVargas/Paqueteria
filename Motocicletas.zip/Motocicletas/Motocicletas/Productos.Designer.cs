﻿namespace Motocicletas
{
    partial class Productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgbusqueda = new System.Windows.Forms.DataGridView();
            this.btnbuscar = new System.Windows.Forms.Button();
            this.btnregresarPro = new System.Windows.Forms.Button();
            this.txtbus = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btncargar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgbusqueda)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgbusqueda
            // 
            this.dtgbusqueda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgbusqueda.Location = new System.Drawing.Point(45, 91);
            this.dtgbusqueda.Name = "dtgbusqueda";
            this.dtgbusqueda.Size = new System.Drawing.Size(929, 324);
            this.dtgbusqueda.TabIndex = 0;
            // 
            // btnbuscar
            // 
            this.btnbuscar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnbuscar.Location = new System.Drawing.Point(450, 16);
            this.btnbuscar.Name = "btnbuscar";
            this.btnbuscar.Size = new System.Drawing.Size(173, 29);
            this.btnbuscar.TabIndex = 1;
            this.btnbuscar.Text = "Buscar";
            this.btnbuscar.UseVisualStyleBackColor = false;
            this.btnbuscar.Click += new System.EventHandler(this.btnbuscar_Click);
            // 
            // btnregresarPro
            // 
            this.btnregresarPro.BackColor = System.Drawing.Color.IndianRed;
            this.btnregresarPro.Location = new System.Drawing.Point(818, 12);
            this.btnregresarPro.Name = "btnregresarPro";
            this.btnregresarPro.Size = new System.Drawing.Size(173, 29);
            this.btnregresarPro.TabIndex = 2;
            this.btnregresarPro.Text = "Regresar";
            this.btnregresarPro.UseVisualStyleBackColor = false;
            this.btnregresarPro.Click += new System.EventHandler(this.btnregresarPro_Click);
            // 
            // txtbus
            // 
            this.txtbus.Location = new System.Drawing.Point(167, 22);
            this.txtbus.Name = "txtbus";
            this.txtbus.Size = new System.Drawing.Size(261, 20);
            this.txtbus.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ingresa la  marca";
            // 
            // btncargar
            // 
            this.btncargar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btncargar.Location = new System.Drawing.Point(12, 56);
            this.btncargar.Name = "btncargar";
            this.btncargar.Size = new System.Drawing.Size(173, 29);
            this.btncargar.TabIndex = 6;
            this.btncargar.Text = "Cargar Productos en tienda";
            this.btncargar.UseVisualStyleBackColor = false;
            this.btncargar.Click += new System.EventHandler(this.btncargar_Click);
            // 
            // Productos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1003, 461);
            this.Controls.Add(this.btncargar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbus);
            this.Controls.Add(this.btnregresarPro);
            this.Controls.Add(this.btnbuscar);
            this.Controls.Add(this.dtgbusqueda);
            this.Name = "Productos";
            this.Text = "Productos";
            this.Load += new System.EventHandler(this.Productos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgbusqueda)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgbusqueda;
        private System.Windows.Forms.Button btnbuscar;
        private System.Windows.Forms.Button btnregresarPro;
        private System.Windows.Forms.TextBox txtbus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btncargar;
    }
}