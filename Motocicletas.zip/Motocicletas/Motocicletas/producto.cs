﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Motocicletas
{
    class producto
    {
        public string action { get; set; }
      
        public producto()
        {
            action = "Motos";
        }
    };
    class resultprodu
    {
        public int idMoto { get; set; }
        public string Nombre { get; set; }
        public string Marca { get; set; }
        public int Costo { get; set; }
        public string Existencia { get; set; }
    };
}
