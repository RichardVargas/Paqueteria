﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;

namespace Motocicletas
{
    public partial class Productos : Form
    {
        public Productos()
        {
            InitializeComponent();
        }

        private void btnregresarPro_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dtgbusqueda.Rows)
            {
                string marca = row.Cells[2].Value.ToString();
                if (row.Cells[2].Value.ToString().TrimEnd().TrimStart() == txtbus.Text)
                {
                    row.Selected = true;
                }
            }
        }

        private void btnborra_Click(object sender, EventArgs e)
        {

        }

        private void Productos_Load(object sender, EventArgs e)
        {

        }

        private void btncargar_Click(object sender, EventArgs e)
        {

            Servicio miServicio = new Servicio();
            producto parametros = new producto();
            JavaScriptSerializer ser = new JavaScriptSerializer();
            string body = ser.Serialize(parametros);
            //MessageBox.Show(body);
            string resultados = miServicio.llamarServicio(body);
            var productos = ser.Deserialize<List<resultprodu>>(resultados);
            // MessageBox.Show(resultados);
            dtgbusqueda.DataSource = null;
            dtgbusqueda.DataSource = productos;
        }
    }
}
